from authlib.deprecate import deprecate

deprecate('Please use `authlib.integrations.httpx_client` instead.')
