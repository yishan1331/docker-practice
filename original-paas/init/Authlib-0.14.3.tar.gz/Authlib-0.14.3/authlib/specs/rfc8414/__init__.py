from .models import AuthorizationServerMetadata
from .well_known import WELL_KNOWN_URL, get_well_known_url
