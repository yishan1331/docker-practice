from authlib.oauth2.rfc7662 import IntrospectionEndpoint
