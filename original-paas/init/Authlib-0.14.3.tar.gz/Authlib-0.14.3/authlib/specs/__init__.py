from authlib.deprecate import deprecate

deprecate('Deprecate "authlib.specs".', '1.0', 'fjvpt', 'sp')
